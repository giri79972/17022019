default_app_config = 'xmpp_http_upload.apps.XmppHttpUploadAppConfig'
